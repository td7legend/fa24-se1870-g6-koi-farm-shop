import React, { useState } from "react"; // Import useState hook
import "./index.scss"; // Import the SCSS file for styling
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUser,
  faShoppingCart,
  faGlobe,
  faMagnifyingGlass,
} from "@fortawesome/free-solid-svg-icons"; // Import the necessary icons

const Header = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false); // State for dropdown
  const [language, setLanguage] = useState("English"); // State for language

  // Function to toggle dropdown visibility
  const toggleDropdown = () => {
    setIsDropdownOpen((prev) => !prev);
  };

  // Function to handle language selection
  const handleLanguageChange = (selectedLanguage) => {
    setLanguage(selectedLanguage); // Update language state
    setIsDropdownOpen(false); // Close the dropdown after selection
  };

  return (
    <header className="header">
      <div className="header-top">
        {/* Logo */}
        <div className="logo">
          <img src="/path/to/logo.png" alt="Golden Koi" />
        </div>

        {/* Search bar */}
        <div className="search-bar">
          <div className="search-input-container">
            {/* Search Icon inside the input */}
            <FontAwesomeIcon icon={faMagnifyingGlass} className="search-icon" />
            <input type="text" placeholder="Search" />
          </div>
          <button type="button">Search</button>
        </div>

        {/* User Options */}
        <div className="user-options">
          <a href="/sign-in" className="register-sign-in">
            <FontAwesomeIcon icon={faUser} className="fa-icon" /> Register/Sign
            in
          </a>
          <a href="/cart" className="cart">
            <FontAwesomeIcon icon={faShoppingCart} className="fa-icon" /> Your
            Cart
          </a>
          <div className="language" onClick={toggleDropdown}>
            <FontAwesomeIcon icon={faGlobe} className="fa-icon" /> {language}
          </div>

          {/* Language Dropdown */}
          {isDropdownOpen && (
            <div className="language-dropdown">
              <div onClick={() => handleLanguageChange("English")}>
                <img
                  src="/path/to/us-flag.png"
                  alt="English"
                  className="flag-icon"
                />
              </div>
              <div onClick={() => handleLanguageChange("Tiếng Việt")}>
                <img
                  src="/path/to/vn-flag.png"
                  alt="Tiếng Việt"
                  className="flag-icon"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Navigation Links - Positioned below the search bar */}
      <nav className="nav-links">
        <a href="/">Home</a>
        <a href="/product">Product</a>
        <a href="/blog">Blog</a>
        <a href="/about-us">About Us</a>
        <a href="/contact-us">Contact Us</a>
      </nav>
    </header>
  );
};

export default Header;
