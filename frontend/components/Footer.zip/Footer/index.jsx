import React from "react";
import "./index.scss"; // Add custom styles here
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"; // Import FontAwesome
import {
  faPhone,
  faLocationDot,
  faEnvelope,
} from "@fortawesome/free-solid-svg-icons"; // Import the necessary icons

function Footer() {
  return (
    <footer className="footer">
      <div className="footer__content">
        <div className="footer__1">
          {/* Logo and contact information */}
          <img
            src="https://firebasestorage.googleapis.com/v0/b/move-management-4fb2c.appspot.com/o/379128395d441b9667fb5156f1bbc970.png?alt=media&token=bb8dc2b6-2551-46e3-bf68-903798945e0d"
            alt="Golden Koi Logo"
            className="footer__logo"
          />
          <p>
            <FontAwesomeIcon icon={faLocationDot} className="fa-icon" />
            Lô E2a-7, Đường D1, D. D1, Long Thành Mỹ, Thành Phố Thủ Đức, Thành
            phố Hồ Chí Minh 700000, Việt Nam
          </p>
          <p>
            <FontAwesomeIcon icon={faPhone} className="fa-icon" /> Hotline:
            024xxx.xxx.xxx
          </p>
          <p>
            <FontAwesomeIcon icon={faEnvelope} className="fa-icon" /> Email:
            info@mywebsite.vn
          </p>
        </div>

        <div className="footer__2">
          {/* Personal Section */}
          <h4>Personal</h4>
          <ul>
            <li>Account</li>
            <li>Forgot Password</li>
            <li>Cart</li>
            <li>Order History</li>
          </ul>
        </div>

        <div className="footer__3">
          {/* About Us Section */}
          <h4>About Us</h4>
          <ul>
            <li>Introduction to Golden Koi</li>
            <li>Store</li>
            <li>Products</li>
            <li>Consignment</li>
          </ul>
        </div>

        <div className="footer__4">
          <h4>Support</h4>
          <ul>
            <li>Contact</li>
            <li>FAQ</li>
            <li>Buying Guide</li>
            <li>Selling Guide</li>
          </ul>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
